﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class validaciones
{
    public bool ValidarEdad(String e)
    {
        bool r = false;
        if (Regex.IsMatch(e, @"^[0-9]+$"))
        {
            r = true;
        }
        else
        {
            r = false;
        }
        return r;
    }
    public bool ValidarNombre(String n)//NOMBRES
    {
        bool r = false;
        //@"^[a-zA-Z _]$";
        if (Regex.IsMatch(n, @"^[a-zA-Z _]+$"))
        {
            r = true;
        }
        else
        {
            r = false;
        }
        return r;
    }
    public bool ValidarTelefono(String t)//TELEFONOS
    {
        bool r = false;
        //@"^[a-zA-Z _]$";
        if (Regex.IsMatch(t, @"^\+?[1-9]\d{9}$"))
        {
            r = true;
        }
        else
        {
            r = false;
        }
        return r;
    }
    public bool ValidarCorreo(String c)//CORREO
    {
        bool r = false;
        //@"^[a-zA-Z _]$";
        if (Regex.IsMatch(c, @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"))
        {
            r = true;
        }
        else
        {
            r = false;
        }
        return r;
    }
}
