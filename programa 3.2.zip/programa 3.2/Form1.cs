﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace programa_3._2
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();
        }

        private void Inicio_Load(object sender, EventArgs e)
        {

        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            StreamWriter archivo = null;
            validaciones val = new validaciones();
           // MessageBox.Show("Hola mundo");
           String nombre = txtNombre.Text;
            String edad = txtEdad.Text;
            if(val.ValidarNombre(nombre)&& val.ValidarEdad(edad))
            {
                archivo = File.AppendText("datos.csv");
                String cadena = nombre+","+edad;
                archivo.WriteLine(cadena);
                archivo.Close();
                txtNombre.Text = "";
                txtEdad.Text = "";
                MessageBox.Show("Datos guardados", "Aviso");
            }
            else
            {
                MessageBox.Show("Datos incorrectos", "Error");
                txtNombre.Text = "";
                txtEdad.Text = "";

            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();//cerrar todas las ventanas
        }

        private void txtEdad_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void mnuAMostrar_Click(object sender, EventArgs e)
        {
            Mostrar mostrar = new Mostrar();
            mostrar.ShowDialog();
            //this.Hide();//ocultar ventana

        }

        private void archivoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 65 && e.KeyChar <= 90)
                || (e.KeyChar >= 97 && e.KeyChar <= 122)
                || (e.KeyChar == 32) || (e.KeyChar == 08))
            {
            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Error de datos", "Error");
            }
                
        }

        private void txtEdad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 48 && e.KeyChar <= 57)
                || (e.KeyChar == 08))
            {

            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Error dato no valido");
            }
        }
    }
}
