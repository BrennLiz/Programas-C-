﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace programa3._3._0
{
    public partial class Form1 : Form
    {
        private bool estado1 = false;
        private bool estado2 = false;
        private int columna = -1;
        private int _id = -1;
        private string c, n, ed;
        public Form1()
        {
            InitializeComponent();
            txtCorreo.ForeColor = Color.Gray;
            txtNombre.ForeColor = Color.Gray;
            txtEdad.ForeColor = Color.Gray;
        }

        private void mnuAAgregar_Click(object sender, EventArgs e)
        {
            estado1 = !estado1;
            panelRegistro.Visible = estado1;
        }

        private void mnuAMostrar_Click(object sender, EventArgs e)
        {
            estado2 = !estado2;
            panelMostrar.Visible = estado2;
            cargarDatos();
        }
        private void cargarDatos()
        {
            if (File.Exists("datos.csv"))
            {
                StreamReader streamReader = File.OpenText("datos.csv");
                String renglon = "";
                int c = 0;
                do
                {
                    try
                    {
                        renglon = streamReader.ReadLine();
                        if (renglon != null)
                        {
                            String[] partes = renglon.Split(',');
                            c++;
                            dataCorreos.Rows.Add(c.ToString(), partes[0], partes[1], partes[2]);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error", "Error");
                    }

                } while (renglon != null);
                streamReader.Close();
            }
            else
            {
                MessageBox.Show("Error no existen datos guardados", "Error");
            }
        }
        private void Eliminardatos(String cor) 
        {
            if (_id != -1)
            {
                StreamReader streamReader = File.OpenText("datos.csv");
                String renglon = "";
                int c = 0;
                StreamWriter aux = null;
                do
                {
                    try
                    {
                        renglon = streamReader.ReadLine();
                        if (renglon != null)
                        {
                            String[] partes = renglon.Split(',');
                            if (partes[0].Equals(c))
                            {

                            }
                            else
                            {
                                aux = File.AppendText("prueba.csv");
                                String cadena = partes[0] + "," + partes[1];
                                aux.WriteLine(cadena);
                                aux.Close();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error", "Error");
                    }
                }while (renglon != null);
                streamReader.Close();
                File.Delete("datos.csv");
                if (File.Exists("prueba.csv"))
                {
                    File.Move("prueba.csv", "datos.csv");
                    File.Delete("prueba.csv");
                }
                dataCorreos.Rows.RemoveAt(_id);
            }
        }

        private void mnuASalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Enter(object sender, EventArgs e)
        {

        }

        private void txtCorreo_Enter(object sender, EventArgs e)
        {
            if (txtCorreo.Text == "Escribe un correo")
            {
                txtCorreo.Text = "";
                txtCorreo.ForeColor = Color.Black;
            }
        }

        private void txtCorreo_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCorreo.Text))
            {
                txtCorreo.Text = "Escribe un correo";
                txtCorreo.ForeColor = Color.Gray;
            }
        }

        private void txtCorreo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if((e.KeyChar >=97 && e.KeyChar <=122)
                ||(e.KeyChar ==08)
                    ||(e.KeyChar == 46)
                    ||(e.KeyChar == 64)
                    ||(e.KeyChar == 95)
                    ||(e.KeyChar >= 48 && e.KeyChar <=57))
            {
            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Error de datos", "Error");
            }
            if (e.KeyChar == 13)
            {
                Guardar();
            }
        }

        private void txtNombre_Enter(object sender, EventArgs e)
        {
            if (txtNombre.Text == "Escribe un nombre")
            {
                txtNombre.Text = "";
                txtNombre.ForeColor = Color.Black;
            }
        }

        private void txtNombre_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNombre.Text))
            {
                txtNombre.Text = "Escribe un nombre";
                txtNombre.ForeColor = Color.Gray;
            }
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 97 && e.KeyChar <= 122)
                || (e.KeyChar == 08)
                || (e.KeyChar == 32)
                    || (e.KeyChar >= 65 && e.KeyChar <= 90))
            {
            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Error de datos", "Error");
            }
            if (e.KeyChar == 13)
            {
                Guardar();
            }
        }

        private void txtEdad_Enter(object sender, EventArgs e)
        {
            if (txtEdad.Text == "Escribe una edad")
            {
                txtEdad.Text = "";
                txtEdad.ForeColor = Color.Black;
            }
        }

        private void txtEdad_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtEdad.Text))
            {
                txtEdad.Text = "Escribe una edad";
                txtEdad.ForeColor = Color.Gray;
            }
        }

        private void txtEdad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 48 && e.KeyChar <= 57)
                || (e.KeyChar == 08))
            {
            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Error de datos", "Error");
            }
            if(e.KeyChar == 13)
            {
                MessageBox.Show("Datos guardados ");
            }
            if(e.KeyChar == 13)
            {
                Guardar();
            }
        }
        private void Guardar()
        {
            String correo = txtCorreo.Text;
            String nombre = txtNombre.Text;
            String edad = txtEdad.Text;
            if (correo.Length == 0 || nombre.Length == 0 || edad.Length == 0) 
            {
                MessageBox.Show("Datos vacios, por favor llenalos");
            }
            else
            {
                if (correo.Equals("Escribe un Correo") || nombre.Equals("Escribe un Nombre")
                    || edad.Equals("Escribe una Edad"))
                {
                    MessageBox.Show("Datos vacios, llenalos por favor");
                }
                else
                {
                    StreamWriter archivo = null;
                    archivo = File.AppendText("datos.csv");
                    archivo.WriteLine(correo + "," + nombre + "," + edad);
                    archivo.Close();
                    MessageBox.Show("Datos guardados","Aviso");
                    dataCorreos.Rows.Clear();
                    cargarDatos();
                }
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
 
        }

        private void btnGuardar_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void panelMostrar_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCorreo_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataCorreos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtCorreo_Click(object sender, EventArgs e)
        {

        }

        private void dataCorreos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            _id = e.RowIndex;
            columna = e.ColumnIndex;
            //MessageBox.Show(columna.ToString());
            if (_id != -1)
            {
                c = dataCorreos.Rows[_id].Cells[1].Value.ToString();
                n = dataCorreos.Rows[_id].Cells[2].Value.ToString();
                ed = dataCorreos.Rows[_id].Cells[2].Value.ToString();
                //MessageBox.Show(u + " : " + p);
            }
            else
            {
                MessageBox.Show("ELige un elemento de la lista");
            }
            if (columna == 4)
            {
                txtCorreo.Text = c;
                txtNombre.Text = n;
                txtEdad.Text = ed;
                panelRegistro.Visible = true;
                txtCorreo.ForeColor = Color.Black;
                txtNombre.ForeColor = Color.Black;
                txtEdad.ForeColor = Color.Black;
                //cargarDatos();
            }
            if (columna == 5)
            {
                Eliminardatos(c);
            }
        }
    }
}
