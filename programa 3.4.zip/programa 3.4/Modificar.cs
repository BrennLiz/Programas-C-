﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace programa_3._4
{
    public partial class Modificar : Form
    {
        public Modificar(string c, string n, string p, string i)
        {
            InitializeComponent();
            lblCodigo.Text = c;
            txtNombre.Text = n;
            txtPrecio.Text = p;
            imagen.Image = Image.FromFile(i);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {

        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
