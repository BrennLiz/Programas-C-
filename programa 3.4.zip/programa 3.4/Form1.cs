﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace programa_3._4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            revisarImagen();
            crearUsuario();
        }

        private void crearUsuario()
        {
            string usuarios = "usuarios.csv";
            StreamWriter streamWriter;
            if (File.Exists(usuarios))
            {

            }
            else
            {
                streamWriter = File.AppendText(usuarios);
                streamWriter.WriteLine("admin,12345,administrador");
                streamWriter.Close();

            }
        }

        private void revisarImagen()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            String rutaImagen = "";
            String rutaCarpeta = @"\imagenes";
            String rutaRaiz = @"imagenes";
            String ruta = "";
            Random randon = new Random();
            int nombreArchivo = randon.Next(1, 1000);

            if (!Directory.Exists(rutaRaiz))
            {
                Directory.CreateDirectory(rutaRaiz);
                Directory.CreateDirectory(rutaRaiz + rutaCarpeta);
                string[] listaDirectorios = Directory.GetDirectories(rutaRaiz);
                MessageBox.Show(listaDirectorios[0], "RutaCarpeta");
                ofd.Filter = "JPEG(*.JPG|*.JPG|*.PNG(*.PNG)|*.PNG)";
                if(ofd.ShowDialog() == DialogResult.OK) 
                { 
                    ruta = ofd.FileName;
                    System.IO.File.Copy(ruta, listaDirectorios[0] + "banner" + ".png",true);
                    banner.Image = Image.FromFile(listaDirectorios[0] + "banner" + ".png");
                }
            }
            else
            {
                //MessageBox.Show("La carpeta ya existe", "Mensaje");
                string[] listaDirectorios = Directory.GetDirectories(rutaRaiz);
                banner.Image = Image.FromFile(listaDirectorios[0] + "banner" + ".png");
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            string usuarios = "usuarios.csv";
            string dato = "";
            string cu = txtUsuario.Text;
            string cp = txtContraseña.Text;
            bool encontro = false;
            if(cu.Length == 0 || cp.Length ==0) 
            {
                MessageBox.Show("Faltan ususario o contraseña", "Alerta");
            }


            if (File.Exists(usuarios))
            {
                StreamReader sr = File.OpenText(usuarios);
                do
                {
                    dato = sr.ReadLine();
                    if (dato != null)
                    {
                        int p = dato.IndexOf(",");
                        int p2 = dato.IndexOf(",",p+1);
                        string u = dato.Substring(0, p);
                        string pa = dato.Substring(p + 1, p2-p-1);
                        //MessageBox.Show(pa, "Ventana");
                        if (u.Equals(cu) && pa.Equals(cp))
                        {
                            encontro = true;
                            break;
                        }
                    }
                    

                } while(dato != null);
                sr.Close();
                if (encontro)
                {
                    this.Hide();
                    productos productos = new productos();
                    productos.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Usuario no existe", "Alerta",MessageBoxButtons.OK);
                }
            }
            else
            {
                MessageBox.Show("Archivo no se encuentra", "Alerta");

            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit(); //cerrar ventana
        }
    }
}
