﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace programa_3._4
{
    public partial class productos : Form
    {
        private string rutaImagenLocal="", Imagenlocal="";
        private int _id = -1;
        private string codigoArchivo;
        private string nombreP;
        private string precioP;
        private string imagenP;

        List<string> img = new List<string>();
        
        public productos()
        {
            InitializeComponent();
            cargarDatos();
            dataProductos.AllowUserToAddRows = false; //elimina la fila en blanco
            dataProductos.ReadOnly = true;


        }
        
        private void cargarDatos()
        {
            dataProductos.Rows.Clear();
            if (File.Exists("productos.csv"))
            {
                StreamReader streamReader = File.OpenText("productos.csv");
                String renglon = "";
                int c = 0;
                do
                {
                    try
                    {
                        renglon = streamReader.ReadLine();
                        if (renglon != null)
                        {
                            String[] partes = renglon.Split(',');
                            c++;
                            dataProductos.Rows.Add(partes[0], partes[1], partes[2], Image.FromFile(partes[3]), partes[3]);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error", "Error");
                    }

                } while (renglon != null);
                streamReader.Close();
            }
            
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            StreamWriter streamWriter;
            string productos = "productos.csv";
            string nombre = txtProducto.Text;
            string precio = txtPrecio.Text;
            if (nombre.Length == 0 || precio.Length == 0)
            {
                MessageBox.Show("Faltan datos", "Alerta");
            }
            else {
                string codigo = nombre.Substring(0, 2);
                int hsistema = DateTime.Now.Hour; //Horas del sistema "hs"
                codigo += hsistema.ToString();

                streamWriter = File.AppendText(productos);
                streamWriter.WriteLine(codigo + "," + nombre + "," + precio + "," + rutaImagenLocal);
                streamWriter.Close();

                MessageBox.Show("Producto guardado", "Mensaje");
                cargarDatos();
                txtProducto.Text = "";
                imgProducto.Image.Dispose();//liberar, quitar
                imgProducto.Image = null;//vacia
                txtPrecio.Text = "";
                lblCodigo.Text = "";

            }
        }
        private void dataProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            _id = e.RowIndex;

            if (_id != -1)
            {
                codigoArchivo = dataProductos.Rows[_id].Cells[0].Value.ToString();
                //ImagenLocal = dataProductos.Rows[_id].Cells[3].Value.ToString();
                //Imagenlocal = dataProductos.Rows[_id].Cells[4].Value.ToString();
                img.Clear();
                img.Add(dataProductos.Rows[_id].Cells[_id].ToString());

                nombreP = dataProductos.Rows[_id].Cells[1].Value.ToString();
                precioP = dataProductos.Rows[_id].Cells[2].Value.ToString();
                imagenP = dataProductos.Rows[_id].Cells[4].Value.ToString();

                MessageBox.Show(Imagenlocal, "Aviso");

            }
            else
            {
                MessageBox.Show("Elige un elemento de la lista");
            }
        }

        private void btnBuscarProducto_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            String rutaImagen = "";
            String rutaCarpeta = @"\imagenes";
            String rutaRaiz = @"imagenes";
            String ruta = "";

            if (txtProducto.Text.Length == 0)
            {
                MessageBox.Show("Escribe el producto primero", "Ventana");
            }
            else
            {
                //DateTime fecha = DateTime.Now.Date;
                //string nombreImagen = fecha.ToShortDateString();
                //nombreImagen = "img" + nombreImagen;
                //nombreImagen += txtProducto.Text + ".png";
                //DateTime hora = DateTime.Now.AddHours(24);
                int ssistema = DateTime.Now.Second;
                string nombreImagen = "";
                nombreImagen = "img" +ssistema.ToString() + txtProducto.Text + ".png";

                ofd.Filter = "JPEG(*.JPG|*.JPG|*.PNG(*.PNG)|*.PNG)";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    string[] listaDirectorios = Directory.GetDirectories(rutaRaiz);
                    ruta = ofd.FileName;
                    System.IO.File.Copy(ruta, listaDirectorios[0] + nombreImagen, true);
                    imgProducto.Image = Image.FromFile(listaDirectorios[0] + nombreImagen);
                    rutaImagenLocal = listaDirectorios[0] + nombreImagen;
                   
                }
                btnAgregar.Enabled = true;
            }
            
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (_id != -1 && img.Count > 0)
            {
                string rutaRelativa = img[0];
                string rutaCompleta = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, rutaRelativa);

                foreach (DataGridViewRow row in dataProductos.Rows)
                {
                    if (row.Cells[3].Value is Image imagenCelda)
                    {
                        imagenCelda.Dispose();


                    }

                }
                if (File.Exists(rutaCompleta))
                {
                    try
                    {
                        
                        File.Delete(rutaCompleta);
                        MessageBox.Show("Imagen eliminada");
                        eliminarDelArchivo(_id);
                        dataProductos.Rows.RemoveAt(_id);

                        _id = -1;
                        img.Clear();
                        codigoArchivo = "";

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al eliminar la imagen: " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("La imagen no fue encontrada en : " + rutaCompleta);

                }
            }
            else
            {
                MessageBox.Show("Selecciona un producto valido.");

            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            Modificar modificar = new Modificar(codigoArchivo,nombreP,precioP,imagenP);
            modificar.ShowDialog();
        }

        private void eliminarDelArchivo(int _id)
        {
            if (_id != -1)
            {
                StreamReader archivo = File.OpenText("productos.csv");
                String renglon = "";
                int c = 0;
                StreamWriter aux = null;
                do
                {
                    try
                    {
                        renglon = archivo.ReadLine();
                        if (renglon != null)
                        {
                            String[] partes = renglon.Split(',');
                            if (partes[0].Equals(codigoArchivo))
                            {
                                MessageBox.Show("Imagen borrada", "RutaLocal");
                            }
                            else
                            {
                                aux = File.AppendText("prueba.csv");
                                String cadena = partes[0] + "," + partes[1] + "," + partes[2] + "," + partes[3];
                                aux.WriteLine(cadena);
                                aux.Close();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error", "Error");
                    }
                } while (renglon != null);

                archivo.Close();
                File.Delete("productos.csv");
                if (File.Exists("prueba.csv"))
                {
                    File.Move("prueba.csv", "productos.csv");
                    File.Delete("prueba.csv");
                }
                //dataProductos.Rows.RemoveAt(_id);
            }
        }

    }

}

