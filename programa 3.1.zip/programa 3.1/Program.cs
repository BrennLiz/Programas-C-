﻿/*Utilizando 2 archivos llenar 1 archivo con 2 datos nombre edad y sexo de 10 personas*/

class Program
{
    static void Main(String[] args)
    {
        validaciones v = new validaciones();
        String n, e,s;
        n = pedirNombre();
        e = pedirEdad();
        s = pedirSexo();

        int con = 0;

        //Crear archivo .txt
        String lista = "archivos.txt";
        bool respuesta = false;
        StreamWriter archivo = null;
        try
        {
            if (!File.Exists(lista))
            {

                archivo = File.AppendText(lista);
                archivo.WriteLine(n + " " + e + " " + s);
                archivo.Close();
                Console.WriteLine("Nombre guardado");
                Console.WriteLine("Edad guardada");
                Console.WriteLine("Sexo guardado");
                Console.WriteLine("Proceso completado.");
                
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
        }

        Console.ReadKey();
        //archivos .txt
    }
    static String pedirNombre()
    {
        validaciones v = new validaciones();
        String n;
        while (true)
        {
            int con = 0;
            Console.WriteLine("Escribe un nombre");
            n = Console.ReadLine();
            if (v.ValidarNombre(n))
            {
                Console.WriteLine("Nombre correcto");
                /*if(con >= 10)
                {
                    break;
                }*/
                
            }
            else
            {
                Console.WriteLine("Nombre incorrecto");
            }
            return n;
        }

    }

    public static String pedirEdad()
    {
        validaciones v = new validaciones();
        String e;
        while (true)
        {
            Console.WriteLine("Escribe la edad");
            e = Console.ReadLine();
            if (v.ValidarEdad(e))
            {
                Console.WriteLine("Edad correcta");
            }
            else
            {
                Console.WriteLine("Edad incorrecta");
            }
            return e;
        }
    }
    public static String pedirSexo()
    {
        validaciones v = new validaciones();
        String s;
        while (true)
        {
            Console.WriteLine("Escribe el sexo");
            s = Console.ReadLine();
            if (v.ValidarNombre(s))
            {
                Console.WriteLine("Sexo correcto");
            }
            else
            {
                Console.WriteLine("Sexo incorrecto");
            }
            return s;
        }
    }
}







