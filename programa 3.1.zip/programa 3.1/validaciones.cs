﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class validaciones
{
    public bool ValidarNombre(String n)
    {
        bool r = false;
        r = (Regex.IsMatch(n, @"^[a-zA-Z _]+$"));
        return r;
    }
    public bool ValidarEdad(String e)
    {
        //bool r = false;
        bool r = (Regex.IsMatch(e, @"^[0-9]+$"));
        return r;
    }
    public bool ValidarSexo(String s)
    {
        bool r = false;
        r = (Regex.IsMatch(s, @"^[a-zA-Z _]+$"));
        return r;
    }
}
