﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Estudiar
{
    public partial class Modificar : Form
    {
        public Modificar(string c, string n, string p1, string p2, string p3)
        {
            InitializeComponent();
            lblClave.Text = c;
            txtNombre.Text = n;
            txtParcial1.Text = p1;
            txtParcial2.Text = p2;
            txtParcial3.Text = p3;
        }

        private void Modificar_Load(object sender, EventArgs e)
        {

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            EliminarDelArchivo(lblClave.Text, txtNombre.Text, txtParcial1.Text, txtParcial2.Text, txtParcial3.Text);
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void EliminarDelArchivo(string n, string p1, string p2, string p3,string text)
        {
            //int _id = Convert.ToInt32(i);
            string clave = n.Substring(0, 2);
            int hsistema = DateTime.Now.Hour;
            clave += hsistema.ToString();

            if (!n.Equals(""))
            {
                StreamReader archivo = File.OpenText("materias.csv");
                String renglon = "";
                StreamWriter aux = null;
                int c = 0;
                do
                {
                    try
                    {
                        renglon = archivo.ReadLine();
                        if (renglon != null)
                        {
                            String[] partes = renglon.Split(',');
                            if (partes[0].Equals(n))
                            {
                                aux = File.AppendText("prueba.csv");
                                String cadena = clave + "," + n + "," + p1 + "," + p2 + "," + p3;
                                aux.WriteLine(cadena);
                                aux.Close();
                            }
                            else
                            {
                                aux = File.AppendText("prueba.csv");
                                String cadena = partes[0] + "," + partes[1] + "," + partes[2] + "," + partes[3] + "," + partes[4];
                                aux.WriteLine(cadena);
                                aux.Close();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error", "Error");
                    }
                } while (renglon != null);
                MessageBox.Show("Datos modificados", "Ventana");
                archivo.Close();
                File.Delete("materias.csv");
                if (File.Exists("prueba.csv"))
                {
                    File.Move("prueba.csv", "materias.csv");
                    File.Delete("prueba.csv");
                }
            }
        }
    }
}
