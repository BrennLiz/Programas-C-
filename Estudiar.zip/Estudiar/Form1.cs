﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
//using static System.Net.Mime.MediaTypeNames;
//using static System.Net.WebRequestMethods;

namespace Estudiar
{
    public partial class Materias : Form
    {
        private int _id = -1;
        private string claveArchivo;
        private string nombreM;
        private string parcial1M;
        private string parcial2M;
        private string parcial3M;
        

        public Materias()
        {
            InitializeComponent();
            cargarDatos();
            dataMaterias.AllowUserToAddRows = false; //elimina la fila en blanco
            dataMaterias.ReadOnly = true; //desactiva la edicion directa del dataGrid
        }

        private void cargarDatos()
        {
            dataMaterias.Rows.Clear();
            if (File.Exists("materias.csv"))
            {
                StreamReader streamReader = File.OpenText("materias.csv");
                String renglon = "";
                //int c = 0;
                do
                {
                    try
                    {
                        renglon = streamReader.ReadLine();
                        if (renglon != null)
                        {
                            String[] partes = renglon.Split(',');
                            //c++;
                            dataMaterias.Rows.Add(partes[0], partes[1], partes[2], partes[3], partes[4]);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error", "Error");
                    }

                } while (renglon != null);
                streamReader.Close();
            }

        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Application.Exit();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            StreamWriter streamWriter;
            string materias = "materias.csv";
            string nombre = txtMateria.Text;
            string parcial1 = txtParcial1.Text;
            string parcial2 = txtParcial2.Text;
            string parcial3 = txtParcial3.Text;
            if (nombre.Length == 0 || parcial1.Length == 0 || parcial2.Length == 0 || parcial3.Length == 0)
            {
                MessageBox.Show("Faltan datos", "Alerta");
            }
            else
            {
                string clave = nombre.Substring(0, 2);
                int hsistema = DateTime.Now.Hour; //Horas del sistema "hs"
                clave += hsistema.ToString();
                lblClave.Text = clave;

                streamWriter = File.AppendText(materias);
                streamWriter.WriteLine(clave + "," + nombre + "," + parcial1 + "," + parcial2 + "," + parcial3);
                streamWriter.Close();

                MessageBox.Show("Materia registrada", "Mensaje");

                cargarDatos();
                //imgProducto.Image.Dispose();//liberar, quitar
                //imgProducto.Image = null;//vacia
                txtMateria.Text = "";//Vaciar las casillas
                txtParcial1.Text = "";
                txtParcial2.Text = "";
                txtParcial3.Text = "";
                lblClave.Text = "";


            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (_id != -1)
            {
                StreamReader archivo = File.OpenText("materias.csv");
                String renglon = "";
                StreamWriter aux = null;
                int c = 0;
                do
                {
                    try
                    {
                        renglon = archivo.ReadLine();
                        if (renglon != null)
                        {
                            String[] partes = renglon.Split(',');
                            if (partes[0].Equals(claveArchivo))
                            {
                                MessageBox.Show("Materia borrada", "Mensaje");
                            }
                            else
                            {
                                aux = File.AppendText("prueba.csv");
                                String cadena = partes[0] + "," + partes[1] + "," + partes[2] + "," + partes[3] + "," + partes[4];
                                aux.WriteLine(cadena);
                                aux.Close();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error", "Error");
                    }
                } while (renglon != null);

                archivo.Close();
                File.Delete("materias.csv");
                if (File.Exists("prueba.csv"))
                {
                    File.Move("prueba.csv", "materias.csv");
                    File.Delete("prueba.csv");
                }

                cargarDatos();
                //dataProductos.Rows.RemoveAt(_id);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void salirToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            //Application.Exit();
            this.Close();
        }

        private void Materias_Load(object sender, EventArgs e)
        {

        }

        private void dataMaterias_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            //OTRA VENTANA
            Modificar modificar = new Modificar(claveArchivo, nombreM, parcial1M, parcial2M, parcial3M);
            modificar.ShowDialog();

            
        }

        private void dataMaterias_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            _id = e.RowIndex;

            if (_id != -1)
            {
                claveArchivo = dataMaterias.Rows[_id].Cells[0].Value.ToString();
                //ImagenLocal = dataProductos.Rows[_id].Cells[3].Value.ToString();
                //Imagenlocal = dataProductos.Rows[_id].Cells[4].Value.ToString();

                nombreM = dataMaterias.Rows[_id].Cells[1].Value.ToString();//posicion de el dataGrid 
                parcial1M = dataMaterias.Rows[_id].Cells[2].Value.ToString();
                parcial2M = dataMaterias.Rows[_id].Cells[3].Value.ToString();
                parcial3M = dataMaterias.Rows[_id].Cells[4].Value.ToString();

                //MessageBox.Show(Imagenlocal, "Aviso");

            }
            else
            {
                MessageBox.Show("Elige un elemento de la lista");
            }
        }

        private void txtMateria_TextChanged(object sender, EventArgs e)
        {
            /*if (int.TryParse(txtMateria.Text, out int valor))
            {
                if (valor <= 50 || valor > 100)
                {
                    MessageBox.Show("Solo se permiten números del 50 al 100");
                    txtMateria.Text = "";
                }
            }
            else if (txtMateria.Text != "")
            {
                MessageBox.Show("Ingrese solo números");
                txtMateria.Text = "";
            }*/
        }
        

        private void txtMateria_KeyPress(object sender, KeyPressEventArgs e)
        {
        //Nombres o letras
        if ((e.KeyChar >= 65 && e.KeyChar <= 90)
                || (e.KeyChar >= 97 && e.KeyChar <= 122)
                || (e.KeyChar == 32) || (e.KeyChar == 08))
        {
        }
        else
        {
            e.Handled = true;
            MessageBox.Show("Dato no valido", "Error");
        }

        }

        private void txtParcial1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 48 && e.KeyChar <= 57)
               || (e.KeyChar == 08))//retroceso
            {

            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Dato no valido","Error");
            }
        }

        private void txtParcial2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 48 && e.KeyChar <= 57)
               || (e.KeyChar == 08))//retroceso
            {

            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Dato no valido", "Error");
            }
        }

        private void txtParcial3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 48 && e.KeyChar <= 57)
               || (e.KeyChar == 08))//retroceso
            {

            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Dato no valido", "Error");
            }
        }

        private void txtMateria_Leave(object sender, EventArgs e)
        {
            //Rango de numeros
            /*if (int.TryParse(txtMateria.Text, out int valor))
            {
                if (valor < 50 || valor > 100)
                {
                    MessageBox.Show("Calificacion no valida","Mensaje");
                    txtMateria.Text = "";
                }
            }*/
        }

        private void Imagen_Click(object sender, EventArgs e)
        {

        }

        private void txtParcial1_TextChanged(object sender, EventArgs e)
        {

        }
    }
    
}
